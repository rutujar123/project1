function viewOffers() {
    alert("Viewing all the best offers!");
  }
  
  function chatNow() {
    alert("Initiating chat with the banquet manager!");
  }